To run the code:
cd to the folder in the terminal and put in the commands:
gcc -o main *.c 
./main


To save the output in the file, execute the binary file as
./main >filename.txt